Spawn.hero_1(0,0);
Spawn.hero_2(200,0);
